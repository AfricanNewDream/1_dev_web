========================================ASTUCE LIVE SERVER=============================================

## Pour commencer
Dans ce petit guide, nous vous donnons des astuces nons exhaustives sur l'utilisation de LIVE SERVER utiliser dans un IDE comme Visual Studio Code.
Il faut noter que que suivantes on étés testées uniquement sur Visual Studio Code, donc cela peut ne pas fonctionner sous d'autre IDE comme PyCharm, etc...
Donc si cela ne fonctionne pas dans votre IDE alors, merci de faire les rechercher en fonction de IDE.

Vous pouvez apprendre d'avantage sur le Live Server : https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer


### Pré-requis

Ce qu'il est requis pour commencer avec ce guide...

- Avoir un ordinateur
- Avoir une connexion internet stable
- Avoir les bases en informatique 

### Démarrer 

Pour installer l'extension dans Visual Studio, merci de visiter le lien : https://www.npmjs.com/package/live-server


## Réalisé avec

Cet guide a été redigé sous Visual Studio Code, donc nous sommes désolés pour les fautes car Visual Studio Code corrige pas les fautes comme Word.


## Contenu de l'astuce sur Live Server
Cette astuce nous permet d'actualiser directement notre code source dans visual situdio code, au lieu d'aller a tout moment raffraichir 
notre navigateur.
1- Aller a extention
2- Saisir live server, et installer le premier qui s'affiche
3- Ensuite aller a fichier -> Add Folder to Workspace...
4- Et l'ajouter dans le dossier ou ce trouve nos projets html et css sur lesquels ont travail
5- En fin on fait un clic droit sur le fichier html ou css de notre choix qui se trouve dans le dossier de l'un de nos projet où on a fait 
le "fichier -> Add Folder to Workspace..." precedent, et cliquer sur : Open with Live Server.

NB: SI CELA NE SE LANCE PAS AUTOMATIQUEMENT, ALORS IL FAUT ALLER DANS EXTENSION VISUAL STUDIO > CLIQUER SUR LE PARAMETRE DE L'EXTENSION LIVE 
SERVER (EXTENSION SETTING)> REGARDER : LIVE SERVER > SETTING: CUSTOM BROWSER, ET SELECTIONNER CHROME.

## Contributions

Si vous souhaitez contribuer, de contacter par mail (ngongang@rodingit.com) pour savoir comment le faire.

## Version

**Dernière version stable : 1.0


## Auteur
R. Dimitry NGONGANG [RODING]

## Réseaux Sociaux
YouTube : @RODING
LinkedIn : @RODING
Discord : @RODING

## E-mail & Portfolio
E-Mail : ngongang@rodingit.com
Portfolio : https://rodingit.com/


## License

Ce projet est sous licence MIT License (MIT) - voir le fichier [LICENSE.md](LICENSE.md) pour plus d'informations.
