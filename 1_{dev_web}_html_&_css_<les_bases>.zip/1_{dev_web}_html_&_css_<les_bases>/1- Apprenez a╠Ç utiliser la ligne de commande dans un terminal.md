========================================APPRENEZ À UTILISER LA LIGNE DE COMMANDE DANS UN TERMINAL=============================================

## Pour commencer
Dans ce petit guide, nous vous donnons un liste non exhaustive des commandes à utiliser dans un terminal Mac, Linux ou Windows.
Il faut noter que que suivantes on étés testées uniquement sur Mac, donc certaines de ces commandes peuvent ne pas fonctionner sous Linux ou 
Windows. Donc si une commande n'est pas reconnus dans votre terminal (Linux ou Windows) alors, utilisez la description de la commande pour 
rechercher sa correspdance pour votre système d'exploitation.

Vous pouvez apprendre d'avantage sur les commande via : 
Mac : https://support.apple.com/fr-mu/guide/terminal/apdb66b5242-0d18-49fc-9c47-a2498b7c91d5/mac
Linux : https://doc.ubuntu-fr.org/tutoriel/console_commandes_de_base
Windows : https://learn.microsoft.com/fr-fr/windows-server/administration/windows-commands/windows-commands


### Pré-requis

Ce qu'il est requis pour commencer avec ce guide...

- Avoir un ordinateur
- Avoir une connexion internet stable
- Avoir les bases en informatique

### Démarrer 

Les étapes pour démarrer ou lancer le terminal....

Sous WINDOWS
1- Ouvrez le menu Démarrer de de votre ordinateur>>Cliquez sur l'icône de Windows (Image intitulée Windowsstart en bas à gauche du bureau) ou  appuyez sur la touche ⊞ Win sur votre clavier.
2- Saisissez cmd ou Invite de commande. Une fois que vous avez ouvert le menu Démarrer, tapez cela depuis votre clavier pour lancer la recherche. L'invite de commandes va apparaitre en haut des résultats
3- Cliquez sur l'appli Image intitulée Windowscmd1. Invite de commandes dans le menu. Le terminal de l'invite de commandes va alors s'ouvrir dans une nouvelle fenêtre.


Sous LINUX 
1- Cliquez sur le bouton d'ouverture de Dash ou pressez la touche ⊞ Win
2- Entrez terminal dans la boite de recherches de Dash. Ensuite vous pouvez montrer ce que vous obtenez au final...
3- Pressez la touche Entrée de votre clavier [3] . Ceci aura pour effet d'ouvrir le terminal.

Sous MAC
Methode 1 : Cliquez sur l'icône Launchpad  dans le Dock>>saisissez Terminal dans le champ de recherche>>puis cliquez sur Terminal.
Methode 2 :  Dans le Finder>>ouvrez le dossier /Applications/Utilitaires>>puis cliquez deux fois sur Terminal.


## Réalisé avec

Ce guide a été redigé sous Visual Studio Code, donc nous sommes désolés pour les fautes car Visual Studio Code corrige pas les fautes comme Word.


## Contenu du guide
>> pwd : permet d'afficher le répertoire courant ;
>> ls : permet d'afficher le contenu d'un répertoire ;
>> ls -a : l'option -a affiche également les fichiers et dossiers cachés, 
>> ls -l : l'option -l modifie l'affichage pour rajouter de nombreuses informations ;
>> cd dossier : permet de se déplacer à l'intérieur d'un répertoire ;
>> mkdir dossier : permet de créer un dossier ;
>> touch nomFichier : permet de créer un fichier ;
>> mv source destination : permet de déplacer des éléments ;
>> * : est un caractère qui peut être utilisé comme substitut pour n'importe quel caractère dans une recherche ; 
>> cp source destination : permet de copier des éléments ;
>> cp -r : l'option -r permet de copier un répertoire ;
>> rm fichiers : permet de supprimer des fichiers ;
>> rm -r dossiers : l'option -r permet de supprimer des répertoires ;
>> man commande : permet d'afficher le manuel d'une commande ;
>> cat/less/more nomFichier : permet d'afficher le contenu d'un fichier ;
>> > : permet de rediriger le résultat d'une commande vers un fichier ;
>> grep motif chemin : permet de faire des recherches dans des fichiers. 


## Contributions

Si vous souhaitez contribuer, de contacter par mail (ngongang@rodingit.com) pour savoir comment le faire.

## Versions

**Dernière version stable : 1.0


## Auteur
R. Dimitry NGONGANG [RODING]

## Réseaux Sociaux
YouTube : @RODING
LinkedIn : @RODING
Discord : @RODING

## E-mail & Portfolio
E-Mail : ngongang@rodingit.com
Portfolio : https://rodingit.com/


## License

Ce projet est sous licence MIT License (MIT) - voir le fichier [LICENSE.md](LICENSE.md) pour plus d'informations.
